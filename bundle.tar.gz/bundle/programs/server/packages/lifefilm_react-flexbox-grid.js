(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"lifefilm:react-flexbox-grid":{"src":{"index.js":["./components/Grid","./components/Row","./components/Col",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/lifefilm_react-flexbox-grid/src/index.js                                                            //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
module.export({Grid:function(){return Grid},Col:function(){return Col},Row:function(){return Row}});var Grid;module.import('./components/Grid',{"default":function(v){Grid=v}});var Row;module.import('./components/Row',{"default":function(v){Row=v}});var Col;module.import('./components/Col',{"default":function(v){Col=v}});
                                                                                                                // 2
                                                                                                                // 3
                                                                                                                //
                                                                                                                // 5
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"components":{"Col.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","react",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/lifefilm_react-flexbox-grid/src/components/Col.js                                                   //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var React,Component,PropTypes;module.import('react',{"default":function(v){React=v},"Component":function(v){Component=v},"PropTypes":function(v){PropTypes=v}});
                                                                                                                //
                                                                                                                //
                                                                                                                // 1
                                                                                                                //
var ModificatorType = PropTypes.oneOfType([PropTypes.number, PropTypes.bool]);                                  // 3
                                                                                                                //
// https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Number/isInteger               //
// add for skip error with SSR                                                                                  //
Number.isInteger = Number.isInteger || function (value) {                                                       // 7
  return typeof value === 'number' && Number.isFinite(value) && !(value % 1);                                   // 8
};                                                                                                              // 11
                                                                                                                //
var Col = function (_Component) {                                                                               //
  _inherits(Col, _Component);                                                                                   //
                                                                                                                //
  function Col(props) {                                                                                         // 15
    _classCallCheck(this, Col);                                                                                 // 15
                                                                                                                //
    var _this = _possibleConstructorReturn(this, _Component.call(this, props));                                 // 15
                                                                                                                //
    _this._classMap = {                                                                                         // 18
      xs: 'col-xs',                                                                                             // 19
      sm: 'col-sm',                                                                                             // 20
      md: 'col-md',                                                                                             // 21
      lg: 'col-lg',                                                                                             // 22
      xsOffset: 'col-xs-offset',                                                                                // 23
      smOffset: 'col-sm-offset',                                                                                // 24
      mdOffset: 'col-md-offset',                                                                                // 25
      lgOffset: 'col-lg-offset'                                                                                 // 26
    };                                                                                                          // 18
    return _this;                                                                                               // 15
  }                                                                                                             // 28
                                                                                                                //
  Col.prototype.render = function render() {                                                                    //
    var classes = [];                                                                                           // 33
                                                                                                                //
    if (this.props.className) {                                                                                 // 35
      classes.push(this.props.className);                                                                       // 36
    }                                                                                                           // 37
                                                                                                                //
    if (this.props.reverse) {                                                                                   // 39
      classes.push('.reverse');                                                                                 // 40
    }                                                                                                           // 41
                                                                                                                //
    for (var key in this.props) {                                                                               // 43
      if (this.props.hasOwnProperty(key) && this._classMap[key]) {                                              // 44
        var colBaseClass = this._classMap[key];                                                                 // 45
        colBaseClass = Number.isInteger(this.props[key]) ? colBaseClass + '-' + this.props[key] : colBaseClass;
        // console.log(colBaseClass);                                                                           //
        classes.push(colBaseClass);                                                                             // 48
      }                                                                                                         // 49
    }                                                                                                           // 50
                                                                                                                //
    return React.createElement(this.props.tagName || 'div', Object.assign({}, this.props, {                     // 52
      className: classes.join(' ')                                                                              // 53
    }), this.props.children);                                                                                   // 52
  };                                                                                                            // 55
                                                                                                                //
  return Col;                                                                                                   //
}(Component);                                                                                                   //
                                                                                                                //
module.export("default",exports.default=(Col));                                                                 //
                                                                                                                //
                                                                                                                //
Col.propTypes = {                                                                                               // 58
  xs: ModificatorType,                                                                                          // 59
  sm: ModificatorType,                                                                                          // 60
  md: ModificatorType,                                                                                          // 61
  lg: ModificatorType,                                                                                          // 62
  xsOffset: PropTypes.number,                                                                                   // 63
  smOffset: PropTypes.number,                                                                                   // 64
  mdOffset: PropTypes.number,                                                                                   // 65
  lgOffset: PropTypes.number,                                                                                   // 66
  reverse: PropTypes.bool,                                                                                      // 67
  className: PropTypes.string,                                                                                  // 68
  tagName: PropTypes.string,                                                                                    // 69
  children: PropTypes.node                                                                                      // 70
};                                                                                                              // 58
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"Grid.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","react",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/lifefilm_react-flexbox-grid/src/components/Grid.js                                                  //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var React,Component,PropTypes;module.import('react',{"default":function(v){React=v},"Component":function(v){Component=v},"PropTypes":function(v){PropTypes=v}});
                                                                                                                //
                                                                                                                //
                                                                                                                // 1
                                                                                                                //
var Grid = function (_Component) {                                                                              //
  _inherits(Grid, _Component);                                                                                  //
                                                                                                                //
  function Grid() {                                                                                             //
    _classCallCheck(this, Grid);                                                                                //
                                                                                                                //
    return _possibleConstructorReturn(this, _Component.apply(this, arguments));                                 //
  }                                                                                                             //
                                                                                                                //
  Grid.prototype.render = function render() {                                                                   //
    return React.createElement(this.props.tagName || 'div', Object.assign({}, this.props, {                     // 5
      className: this.props.fluid ? 'container-fluid' : 'container'                                             // 6
    }), this.props.children);                                                                                   // 5
  };                                                                                                            // 8
                                                                                                                //
  return Grid;                                                                                                  //
}(Component);                                                                                                   //
                                                                                                                //
module.export("default",exports.default=(Grid));                                                                //
                                                                                                                //
                                                                                                                //
Grid.propTypes = {                                                                                              // 11
  fluid: PropTypes.bool,                                                                                        // 12
  className: PropTypes.string,                                                                                  // 13
  tagName: PropTypes.string,                                                                                    // 14
  children: PropTypes.node                                                                                      // 15
};                                                                                                              // 11
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"Row.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","react",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/lifefilm_react-flexbox-grid/src/components/Row.js                                                   //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});var React,Component,PropTypes;module.import('react',{"default":function(v){React=v},"Component":function(v){Component=v},"PropTypes":function(v){PropTypes=v}});
                                                                                                                //
                                                                                                                //
                                                                                                                // 1
                                                                                                                //
var ModificatorType = PropTypes.oneOf(['xs', 'sm', 'md', 'lg']);                                                // 3
                                                                                                                //
var Row = function (_Component) {                                                                               //
  _inherits(Row, _Component);                                                                                   //
                                                                                                                //
  function Row() {                                                                                              //
    _classCallCheck(this, Row);                                                                                 //
                                                                                                                //
    return _possibleConstructorReturn(this, _Component.apply(this, arguments));                                 //
  }                                                                                                             //
                                                                                                                //
  Row.prototype.render = function render() {                                                                    //
    return React.createElement(this.props.tagName || 'div', Object.assign({}, this.props, {                     // 7
      className: 'row'                                                                                          // 8
    }), this.props.children);                                                                                   // 7
  };                                                                                                            // 10
                                                                                                                //
  return Row;                                                                                                   //
}(Component);                                                                                                   //
                                                                                                                //
module.export("default",exports.default=(Row));                                                                 //
                                                                                                                //
                                                                                                                //
Row.propTypes = {                                                                                               // 13
  reverse: PropTypes.bool,                                                                                      // 14
  start: ModificatorType,                                                                                       // 15
  center: ModificatorType,                                                                                      // 16
  end: ModificatorType,                                                                                         // 17
  top: ModificatorType,                                                                                         // 18
  middle: ModificatorType,                                                                                      // 19
  bottom: ModificatorType,                                                                                      // 20
  around: ModificatorType,                                                                                      // 21
  between: ModificatorType,                                                                                     // 22
  first: ModificatorType,                                                                                       // 23
  last: ModificatorType,                                                                                        // 24
  className: PropTypes.string,                                                                                  // 25
  tagName: PropTypes.string,                                                                                    // 26
  children: PropTypes.node                                                                                      // 27
};                                                                                                              // 13
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}}}},{"extensions":[".js",".json"]});
var exports = require("./node_modules/meteor/lifefilm:react-flexbox-grid/src/index.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['lifefilm:react-flexbox-grid'] = exports;

})();

//# sourceMappingURL=lifefilm_react-flexbox-grid.js.map
