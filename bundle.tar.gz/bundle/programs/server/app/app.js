var require = meteorInstall({"imports":{"api":{"projects":{"server":{"publications.js":["meteor/meteor","meteor/check","../projects.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/projects/server/publications.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});module.import('../projects.js');
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
/* global Projects:true*/                                                                                              //
/* eslint no-undef: "error"*/                                                                                          //
                                                                                                                       //
Meteor.publish('projects', function projectsPublish() {                                                                // 8
  var currentUser = Meteor.users.findOne(this.userId);                                                                 // 9
                                                                                                                       //
  if (currentUser == null || currentUser.profile == null) {                                                            // 11
    return null;                                                                                                       // 12
  }                                                                                                                    // 13
                                                                                                                       //
  if (currentUser.profile.isAdmin) {                                                                                   // 15
    var _projects = Projects.find();                                                                                   // 16
    return _projects;                                                                                                  // 17
  }                                                                                                                    // 18
                                                                                                                       //
  var projects = Projects.find({ $or: [{                                                                               // 20
      managers: this.userId }, { employees: this.userId }] });                                                         // 21
  return projects;                                                                                                     // 22
});                                                                                                                    // 23
                                                                                                                       //
Meteor.publish('projectGet', function retrieveProject(projectId) {                                                     // 25
  check(projectId, String);                                                                                            // 26
  var currentUser = Meteor.users.findOne(this.userId);                                                                 // 27
                                                                                                                       //
  if (currentUser == null || currentUser.profile == null) {                                                            // 29
    return null;                                                                                                       // 30
  }                                                                                                                    // 31
                                                                                                                       //
  if (currentUser.profile.isAdmin) {                                                                                   // 33
    var _project = Projects.find({ _id: projectId });                                                                  // 34
    return _project;                                                                                                   // 35
  }                                                                                                                    // 36
                                                                                                                       //
  var project = Projects.find({ $and: [{ _id: projectId }, { $or: [{                                                   // 38
        managers: this.userId }, { employees: this.userId }] }] });                                                    // 39
  return project;                                                                                                      // 40
});                                                                                                                    // 41
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["meteor/meteor","meteor/check","./projects.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/projects/methods.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});module.import('./projects.js');
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
/* global Projects:true*/                                                                                              //
/* eslint no-undef: "error"*/                                                                                          //
                                                                                                                       //
// Security                                                                                                            //
Projects.deny({                                                                                                        // 9
  insert: function insert() {                                                                                          // 10
    return true;                                                                                                       // 10
  },                                                                                                                   // 10
  update: function update() {                                                                                          // 11
    return true;                                                                                                       // 11
  },                                                                                                                   // 11
  remove: function remove() {                                                                                          // 12
    return true;                                                                                                       // 12
  }                                                                                                                    // 12
});                                                                                                                    // 9
                                                                                                                       //
// Helpers                                                                                                             //
function isAdmin() {                                                                                                   // 16
  var currentUser = Meteor.user();                                                                                     // 17
                                                                                                                       //
  if (currentUser == null || currentUser.profile == null) {                                                            // 19
    return false;                                                                                                      // 20
  }                                                                                                                    // 21
                                                                                                                       //
  return currentUser.profile.isAdmin;                                                                                  // 23
}                                                                                                                      // 24
                                                                                                                       //
function isManager(projectId) {                                                                                        // 26
  var currentUser = Meteor.user();                                                                                     // 27
                                                                                                                       //
  if (currentUser == null || currentUser.profile == null) {                                                            // 29
    return false;                                                                                                      // 30
  }                                                                                                                    // 31
                                                                                                                       //
  var project = Projects.findOne({ managers: { $in: [currentUser._id] }, _id: projectId });                            // 33
  return project != null || currentUser.profile.isAdmin;                                                               // 34
}                                                                                                                      // 35
                                                                                                                       //
Meteor.methods({                                                                                                       // 37
  /**                                                                                                                  //
  Creates new project using the name of the project and one manager provided                                           //
  @param name, String; name of project                                                                                 //
  @param mgr, String; UserId of manager                                                                                //
  @return boolean; returns true if project was successfully created and added to collection                            //
  **/                                                                                                                  //
  'projects.create': function createProject(name, mgr) {                                                               // 44
    check(name, String);                                                                                               // 45
    check(mgr, String);                                                                                                // 46
                                                                                                                       //
    if (isAdmin()) {                                                                                                   // 48
      return Projects.insert({ name: name,                                                                             // 49
        managers: [mgr],                                                                                               // 50
        employees: [],                                                                                                 // 51
        bornOn: new Date(),                                                                                            // 52
        isActive: true,                                                                                                // 53
        inactiveDate: null });                                                                                         // 54
    }                                                                                                                  // 55
    throw new Meteor.Error('projects.create.unauthorized', 'You do not have permission to create projects.');          // 56
  },                                                                                                                   // 57
                                                                                                                       //
  'projects.addManager': function addManager(proj, user) {                                                             // 59
    // set manager(s) to the project                                                                                   //
    check(proj, String);                                                                                               // 61
    check(user, String);                                                                                               // 62
                                                                                                                       //
    if (isAdmin()) {                                                                                                   // 64
      var result = Projects.update({ _id: proj }, { $addToSet: { managers: user } });                                  // 65
                                                                                                                       //
      return result.nModified === 1;                                                                                   // 68
    }                                                                                                                  // 69
    throw new Meteor.Error('projects.addManager.unauthorized', 'You do not have permission to add managers.');         // 70
  },                                                                                                                   // 71
                                                                                                                       //
  'projects.removeManager': function removeManager(proj, user) {                                                       // 73
    // remove manager from project                                                                                     //
    check(proj, String);                                                                                               // 75
    check(user, String);                                                                                               // 76
                                                                                                                       //
    if (isAdmin()) {                                                                                                   // 78
      var result = Projects.update({ _id: proj }, { $pull: { managers: user } });                                      // 79
                                                                                                                       //
      return result.nModified === 1;                                                                                   // 82
    }                                                                                                                  // 83
    throw new Meteor.Error('projects.removeManager.unauthorized', 'You do not have permission to remove managers.');   // 84
  },                                                                                                                   // 85
                                                                                                                       //
  'projects.addEmployee': function addEmployee(proj, user) {                                                           // 87
    // add employees to project                                                                                        //
    check(proj, String);                                                                                               // 89
    check(user, String);                                                                                               // 90
                                                                                                                       //
    if (isManager(proj)) {                                                                                             // 92
      var result = Projects.update({ _id: proj }, { $addToSet: { employees: user } });                                 // 93
                                                                                                                       //
      return result.nModified === 1;                                                                                   // 96
    }                                                                                                                  // 97
    throw new Meteor.Error('projects.addEmployee.unauthorized', 'You do not have permission to add employees.');       // 98
  },                                                                                                                   // 99
                                                                                                                       //
  'projects.removeEmployee': function removeEmployee(proj, user) {                                                     // 101
    // remove employees from project                                                                                   //
    check(proj, String);                                                                                               // 103
    check(user, String);                                                                                               // 104
                                                                                                                       //
    if (isManager(proj)) {                                                                                             // 106
      var result = Projects.update({ _id: proj }, { $pull: { employees: user } });                                     // 107
                                                                                                                       //
      return result.nModified === 1;                                                                                   // 110
    }                                                                                                                  // 111
    throw new Meteor.Error('projects.removeEmployee.unauthorized', 'You do not have permission to remove employees.');
  },                                                                                                                   // 113
                                                                                                                       //
  'projects.activate': function activate(proj) {                                                                       // 115
    // activate project                                                                                                //
    check(proj, String);                                                                                               // 117
                                                                                                                       //
    if (isAdmin()) {                                                                                                   // 119
      var result = Projects.update({ _id: proj }, { $set: { isActive: true, inactiveDate: null } });                   // 120
                                                                                                                       //
      return result.nModified === 1;                                                                                   // 123
    }                                                                                                                  // 124
    throw new Meteor.Error('projects.activate.unauthorized', 'You do not have permission to activate projects.');      // 125
  },                                                                                                                   // 126
                                                                                                                       //
  'projects.deactivate': function deactivate(proj) {                                                                   // 128
    // deactivate project                                                                                              //
    check(proj, String);                                                                                               // 130
                                                                                                                       //
    if (isAdmin()) {                                                                                                   // 132
      var result = Projects.update({ _id: proj }, { $set: { isActive: false, inactiveDate: new Date() } });            // 133
                                                                                                                       //
      return result.nModified === 1;                                                                                   // 136
    }                                                                                                                  // 137
    throw new Meteor.Error('projects.deactivate.unauthorized', 'You do not have permission to deactivate projects.');  // 138
  },                                                                                                                   // 139
                                                                                                                       //
  'projects.editName': function editName(proj, newname) {                                                              // 141
    check(proj, String);                                                                                               // 142
    check(newname, String);                                                                                            // 143
                                                                                                                       //
    if (newname === '') {                                                                                              // 145
      throw new Meteor.Error('projects.editName.emptyName', 'You did not provide a new name for the project.');        // 146
    }                                                                                                                  // 147
                                                                                                                       //
    if (isAdmin()) {                                                                                                   // 149
      var result = Projects.update({ _id: proj }, { $set: { name: newname } });                                        // 150
                                                                                                                       //
      return result.nModified === 1;                                                                                   // 153
    }                                                                                                                  // 154
    throw new Meteor.Error('projects.editName.unauthorized', 'You do not have permission to deactivate projects.');    // 155
  }                                                                                                                    // 156
});                                                                                                                    // 37
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"projects.js":["meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/projects/projects.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});                                                // 1
                                                                                                                       //
/* global Projects:true*/                                                                                              //
/* eslint no-undef: "error"*/                                                                                          //
                                                                                                                       //
Projects = new Mongo.Collection('projects');                                                                           // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"requests":{"server":{"publications.js":["meteor/meteor","../requests.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/requests/server/publications.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});module.import('../requests.js');            // 1
// import { check } from 'meteor/check';                                                                               //
                                                                                                                       // 3
                                                                                                                       //
/* global Requests:true*/                                                                                              //
/* eslint no-undef: "error"*/                                                                                          //
                                                                                                                       //
Meteor.publish('requests', function requestsPublish() {                                                                // 8
  var currentUser = Meteor.users.findOne(this.userId);                                                                 // 9
                                                                                                                       //
  if (currentUser == null || currentUser.profile == null) {                                                            // 11
    return null;                                                                                                       // 12
  }                                                                                                                    // 13
                                                                                                                       //
  // if (currentUser.profile.isAdmin) {                                                                                //
  //   const reports = Reports.find();                                                                                 //
  //   return reports;                                                                                                 //
  // }                                                                                                                 //
                                                                                                                       //
  var requests = Requests.find({ userId: this.userId });                                                               // 20
  return requests;                                                                                                     // 21
});                                                                                                                    // 22
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["meteor/meteor","meteor/check","./requests.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/requests/methods.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});module.import('./requests.js');
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
/* global Requests:true*/                                                                                              //
/* eslint no-undef: "error"*/                                                                                          //
                                                                                                                       //
Meteor.methods({                                                                                                       // 8
  'requests.create': function createRequest(proj, desc, est, vend, prt, qty, unt) {                                    // 9
    var currentUserId = Meteor.userId();                                                                               // 10
    check(proj, String);                                                                                               // 11
    check(desc, String);                                                                                               // 12
    check(est, Number);                                                                                                // 13
    check(vend, String);                                                                                               // 14
    check(prt, String);                                                                                                // 15
    check(qty, Number);                                                                                                // 16
    check(unt, Number);                                                                                                // 17
                                                                                                                       //
    var newReq = {                                                                                                     // 19
      userId: currentUserId,                                                                                           // 20
      projectId: proj,                                                                                                 // 21
      bornOn: new Date(),                                                                                              // 22
      description: desc,                                                                                               // 23
      estCost: est,                                                                                                    // 24
      vendor: vend,                                                                                                    // 25
      partNo: prt,                                                                                                     // 26
      quantity: qty,                                                                                                   // 27
      unitCost: unt                                                                                                    // 28
    };                                                                                                                 // 19
                                                                                                                       //
    Requests.schema.validate(newReq);                                                                                  // 31
                                                                                                                       //
    return Requests.insert(newReq);                                                                                    // 33
  },                                                                                                                   // 34
                                                                                                                       //
  'requests.statEdit': function apprDeclReq(reqId, stat, msg) {                                                        // 36
    check(reqId, String);                                                                                              // 37
    check(stat, Boolean);                                                                                              // 38
    check(msg, String);                                                                                                // 39
                                                                                                                       //
    var result = Requests.update({ _id: reqId }, { $set: { status: stat, statMsg: msg } });                            // 41
                                                                                                                       //
    return result.nModified === 1;                                                                                     // 44
  }                                                                                                                    // 45
                                                                                                                       //
});                                                                                                                    // 8
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"requests.js":["meteor/mongo","meteor/aldeed:simple-schema",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/requests/requests.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var SimpleSchema;module.import('meteor/aldeed:simple-schema',{"SimpleSchema":function(v){SimpleSchema=v}});
                                                                                                                       // 2
                                                                                                                       //
/* global Requests:true*/                                                                                              //
/* eslint no-undef: "error"*/                                                                                          //
                                                                                                                       //
Requests = new Mongo.Collection('requests');                                                                           // 7
                                                                                                                       //
Requests.schema = new SimpleSchema({                                                                                   // 9
  userId: { type: String, regEx: SimpleSchema.RegEx.Id },                                                              // 10
  projectId: { type: String, regEx: SimpleSchema.RegEx.Id },                                                           // 11
  status: { type: Boolean, optional: true },                                                                           // 12
  statMsg: { type: String, optional: true },                                                                           // 13
  bornOn: { type: Date,                                                                                                // 14
    autoValue: function autoValue() {                                                                                  // 15
      var date = Date.now();                                                                                           // 16
      return date;                                                                                                     // 17
    }                                                                                                                  // 18
  },                                                                                                                   // 14
  description: { type: String },                                                                                       // 20
  estCost: { type: Number, decimal: true },                                                                            // 21
  vendor: { type: String },                                                                                            // 22
  partNo: { type: String },                                                                                            // 23
  quantity: { type: Number, defaultValue: 1 },                                                                         // 24
  unitCost: { type: Number, decimal: true },                                                                           // 25
  receipt: { type: String, optional: true }                                                                            // 26
});                                                                                                                    // 9
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"users":{"server":{"publications.js":["meteor/meteor","meteor/check","../../projects/projects.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/users/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});module.import('../../projects/projects.js');
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
/* global Projects:true*/                                                                                              //
                                                                                                                       //
Meteor.publish('users', function usersPublish() {                                                                      // 7
  // Return all user documents the current user can view                                                               //
  var currentUser = Meteor.users.findOne(this.userId);                                                                 // 9
                                                                                                                       //
  if (currentUser == null || currentUser.profile == null) {                                                            // 11
    return null;                                                                                                       // 12
  }                                                                                                                    // 13
                                                                                                                       //
  if (currentUser.profile.isAdmin) {                                                                                   // 15
    var users = Meteor.users.find();                                                                                   // 16
    return users;                                                                                                      // 17
  }                                                                                                                    // 18
  return Meteor.users.find({ _id: this.userId });                                                                      // 19
});                                                                                                                    // 20
                                                                                                                       //
Meteor.publish('usersInProject', function projectUsersPublish(projectId) {                                             // 22
  // Given a projectId, return the _id and name of all managers and employees in the project                           //
  check(projectId, String);                                                                                            // 24
                                                                                                                       //
  var currentUser = Meteor.users.findOne(this.userId);                                                                 // 26
                                                                                                                       //
  if (currentUser == null || currentUser.profile == null) {                                                            // 28
    return null;                                                                                                       // 29
  }                                                                                                                    // 30
                                                                                                                       //
  var project = Projects.findOne(projectId);                                                                           // 32
  if (project != null && (project.managers.indexOf(this.userId) !== -1 || project.employees.indexOf(this.userId) !== -1 || currentUser.profile.isAdmin)) {
    var userIds = project.managers.concat(project.employees);                                                          // 36
    var users = Meteor.users.find({ _id: { $in: userIds } }, { 'profile.name': 1 });                                   // 37
    return users;                                                                                                      // 38
  }                                                                                                                    // 39
  return null;                                                                                                         // 40
});                                                                                                                    // 41
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["meteor/meteor","meteor/accounts-base","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/users/methods.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
// Security                                                                                                            //
Meteor.users.deny({                                                                                                    // 6
  insert: function insert() {                                                                                          // 7
    return true;                                                                                                       // 7
  },                                                                                                                   // 7
  update: function update() {                                                                                          // 8
    return true;                                                                                                       // 8
  },                                                                                                                   // 8
  remove: function remove() {                                                                                          // 9
    return true;                                                                                                       // 9
  }                                                                                                                    // 9
});                                                                                                                    // 6
                                                                                                                       //
Meteor.methods({                                                                                                       // 12
  /**                                                                                                                  //
  Gets the user with the given userId                                                                                  //
  @param userId {String} user's id                                                                                     //
  @return {JSON} Object representing the user, or null if cannot access                                                //
  */                                                                                                                   //
  'users.getOne': function getOne(userId) {                                                                            // 18
    check(userId, String);                                                                                             // 19
                                                                                                                       //
    var currentUser = Meteor.user();                                                                                   // 21
    if (currentUser == null || currentUser.profile == null) {                                                          // 22
      return null;                                                                                                     // 23
    }                                                                                                                  // 24
                                                                                                                       //
    var projection = { emails: 1, 'profile.name': 1, 'profile.isAdmin': 1 };                                           // 26
    return Meteor.users.findOne(userId, projection);                                                                   // 27
  },                                                                                                                   // 28
                                                                                                                       //
  /**                                                                                                                  //
  Creates a new user in the database                                                                                   //
  TODO: Use email to send password reset link/confirmation email                                                       //
  @param email {String} email address                                                                                  //
  @param name {String} user's name                                                                                     //
  @param isAdmin {Boolean} whether or not the user is an admin                                                         //
  @return {Boolean} true if successfully added                                                                         //
  */                                                                                                                   //
  'users.new': function newUser(email, name, isAdmin) {                                                                // 38
    check(email, String);                                                                                              // 39
    check(name, String);                                                                                               // 40
    check(isAdmin, Boolean);                                                                                           // 41
                                                                                                                       //
    var currentUser = Meteor.user();                                                                                   // 43
                                                                                                                       //
    if (currentUser == null || currentUser.profile == null || !currentUser.profile.isAdmin) {                          // 45
      throw new Meteor.Error('users.new.unauthorized', 'You cannot create new users');                                 // 46
    }                                                                                                                  // 47
    if (/^[A-Z0-9'.1234z_%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(email)) {                                               // 48
      var username = email.substr(0, email.indexOf('@'));                                                              // 49
      var userId = Accounts.createUser({                                                                               // 50
        username: username,                                                                                            // 51
        email: email,                                                                                                  // 52
        profile: {                                                                                                     // 53
          name: name,                                                                                                  // 54
          isAdmin: isAdmin,                                                                                            // 55
          autoInternet: true,                                                                                          // 56
          autoPhone: true                                                                                              // 57
        }                                                                                                              // 53
      });                                                                                                              // 50
      Accounts.sendEnrollmentEmail(userId);                                                                            // 60
      return true;                                                                                                     // 61
    }                                                                                                                  // 62
    throw new Meteor.Error('users.new.invalidEmail', 'Email address is not valid');                                    // 63
  },                                                                                                                   // 64
                                                                                                                       //
  /**                                                                                                                  //
  Updates the user's profile. Only admins can update profiles                                                          //
  @param userId {String} id of the user                                                                                //
  @param profile {JSON} Object with name, isAdmin, autoInternet, and autoPhone fields                                  //
  @return {JSON} Object with the fields that were successfully updated                                                 //
  */                                                                                                                   //
  'users.update': function updateUser(userId, profile) {                                                               // 72
    check(userId, String);                                                                                             // 73
    check(profile, {                                                                                                   // 74
      name: String,                                                                                                    // 75
      isAdmin: Boolean,                                                                                                // 76
      autoInternet: Boolean,                                                                                           // 77
      autoPhone: Boolean                                                                                               // 78
    });                                                                                                                // 74
                                                                                                                       //
    var currentUser = Meteor.user();                                                                                   // 81
    if (currentUser == null || currentUser.profile == null) {                                                          // 82
      throw new Meteor.Error('users.update.nouser', 'You are not a valid user');                                       // 83
    }                                                                                                                  // 84
                                                                                                                       //
    var oldUser = Meteor.users.findOne(userId);                                                                        // 86
    if (oldUser == null || oldUser.profile == null) {                                                                  // 87
      throw new Meteor.Error('users.update.invalidId', 'No user found with the given userId');                         // 88
    }                                                                                                                  // 89
                                                                                                                       //
    var currentUserId = Meteor.userId();                                                                               // 91
    if (!currentUser.profile.isAdmin && currentUserId !== userId) {                                                    // 92
      throw new Meteor.Error('users.update.permissionDenied', 'You do not have required permissions to update user');  // 93
    }                                                                                                                  // 94
                                                                                                                       //
    Meteor.users.update(userId, {                                                                                      // 96
      $set: {                                                                                                          // 97
        profile: {                                                                                                     // 98
          name: profile.name,                                                                                          // 99
          isAdmin: profile.isAdmin,                                                                                    // 100
          autoInternet: profile.autoInternet,                                                                          // 101
          autoPhone: profile.autoPhone                                                                                 // 102
        }                                                                                                              // 98
      }                                                                                                                // 97
    });                                                                                                                // 96
                                                                                                                       //
    return {                                                                                                           // 107
      name: true,                                                                                                      // 108
      isAdmin: true,                                                                                                   // 109
      autoInternet: true,                                                                                              // 110
      autoPhone: true                                                                                                  // 111
    };                                                                                                                 // 107
  },                                                                                                                   // 113
                                                                                                                       //
  /**                                                                                                                  //
  Deletes the given user. Only admins can do this                                                                      //
  @param userId {String} id of the user                                                                                //
  @return {Boolean} true if delete is successful                                                                       //
  */                                                                                                                   //
  'users.remove': function removeUser(userId) {                                                                        // 120
    check(userId, String);                                                                                             // 121
                                                                                                                       //
    var currentUser = Meteor.user();                                                                                   // 123
    if (currentUser == null || currentUser.profile == null) {                                                          // 124
      throw new Meteor.Error('users.update.nouser', 'You are not a valid user');                                       // 125
    }                                                                                                                  // 126
                                                                                                                       //
    if (Meteor.userId() === userId || !currentUser.profile.isAdmin) {                                                  // 128
      throw new Meteor.Error('users.remove.unauthorized', 'Cannot delete this user');                                  // 129
    }                                                                                                                  // 130
                                                                                                                       //
    Meteor.users.remove({ _id: userId });                                                                              // 132
                                                                                                                       //
    return true;                                                                                                       // 134
  }                                                                                                                    // 135
});                                                                                                                    // 12
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"server":{"fixtures.js":["meteor/meteor","meteor/accounts-base","../../api/projects/projects.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/fixtures.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});module.import('../../api/projects/projects.js');
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
/* global Projects:true*/                                                                                              //
/* eslint no-undef: "error"*/                                                                                          //
function seedUsers() {                                                                                                 // 7
  var users = ['greenjm', 'havensid', 'kerrickm', 'weissna'];                                                          // 8
                                                                                                                       //
  for (var i = 0; i < users.length; i += 1) {                                                                          // 10
    var user = users[i];                                                                                               // 11
    Accounts.createUser({                                                                                              // 12
      username: user + '+admin',                                                                                       // 13
      email: user + '+admin@rose-hulman.edu',                                                                          // 14
      password: '12345678',                                                                                            // 15
      profile: {                                                                                                       // 16
        name: user + ' Admin',                                                                                         // 17
        isAdmin: true,                                                                                                 // 18
        autoInternet: true,                                                                                            // 19
        autoPhone: true                                                                                                // 20
      }                                                                                                                // 16
    });                                                                                                                // 12
    Accounts.createUser({                                                                                              // 23
      username: user,                                                                                                  // 24
      email: user + '@rose-hulman.edu',                                                                                // 25
      password: '12345678',                                                                                            // 26
      profile: {                                                                                                       // 27
        name: user,                                                                                                    // 28
        isAdmin: false,                                                                                                // 29
        autoInternet: true,                                                                                            // 30
        autoPhone: true                                                                                                // 31
      }                                                                                                                // 27
    });                                                                                                                // 23
  }                                                                                                                    // 34
}                                                                                                                      // 35
                                                                                                                       //
function seedProjects() {                                                                                              // 37
  for (var i = 0; i < 5; i += 1) {                                                                                     // 38
    var userIndex = i;                                                                                                 // 39
    if (userIndex >= Meteor.users.find().count()) {                                                                    // 40
      userIndex = 0;                                                                                                   // 41
    }                                                                                                                  // 42
    var user = Meteor.users.find().fetch()[userIndex];                                                                 // 43
    Projects.insert({                                                                                                  // 44
      name: 'Test Project ' + i,                                                                                       // 45
      managers: [user._id],                                                                                            // 46
      employees: [],                                                                                                   // 47
      bornOn: new Date(),                                                                                              // 48
      isActive: true,                                                                                                  // 49
      inactiveDate: null                                                                                               // 50
    });                                                                                                                // 44
  }                                                                                                                    // 52
}                                                                                                                      // 53
                                                                                                                       //
// Uncomment the following line to reseed users                                                                        //
// Meteor.users.remove({});                                                                                            //
if (Meteor.users.find().count() <= 0) {                                                                                // 57
  // Seed new users                                                                                                    //
  seedUsers();                                                                                                         // 59
}                                                                                                                      // 60
                                                                                                                       //
// Uncomment the following line to reseed projects                                                                     //
// Projects.remove({});                                                                                                //
if (Projects.find().count() <= 0) {                                                                                    // 64
  // Seed new projects                                                                                                 //
  seedProjects();                                                                                                      // 66
}                                                                                                                      // 67
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"server":{"main.js":["meteor/meteor","../imports/startup/server/fixtures.js","../imports/api/users/methods.js","../imports/api/projects/methods.js","../imports/api/requests/methods.js","../imports/api/projects/projects.js","../imports/api/requests/requests.js","../imports/api/projects/server/publications.js","../imports/api/users/server/publications.js","../imports/api/requests/server/publications.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});module.import('../imports/startup/server/fixtures.js');module.import('../imports/api/users/methods.js');module.import('../imports/api/projects/methods.js');module.import('../imports/api/requests/methods.js');module.import('../imports/api/projects/projects.js');module.import('../imports/api/requests/requests.js');module.import('../imports/api/projects/server/publications.js');module.import('../imports/api/users/server/publications.js');module.import('../imports/api/requests/server/publications.js');
                                                                                                                       // 2
                                                                                                                       //
// Methods                                                                                                             //
                                                                                                                       // 5
                                                                                                                       // 6
                                                                                                                       // 7
                                                                                                                       //
// Collections                                                                                                         //
                                                                                                                       // 10
                                                                                                                       // 11
                                                                                                                       //
// Publications                                                                                                        //
                                                                                                                       // 14
                                                                                                                       // 15
                                                                                                                       // 16
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 18
  // code to run on server at startup                                                                                  //
  process.env.MAIL_URL = 'smtp://meteor.no.reply%40gmail.com:Password&123@smtp.gmail.com:465';                         // 20
});                                                                                                                    // 21
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
